# E-Commerce System - Fawry Quantum Internship Challenge

## Overview
This is a complete e-commerce system implementation that handles products, shopping carts, checkout processes, and shipping services. The system supports both perishable and non-perishable products, with shipping and non-shipping items.

## Features Implemented

### Product Management
- **Product Types**: Support for both perishable (Cheese, Biscuits) and non-perishable (TV, Mobile) products
- **Shipping Support**: Products can be shippable (with weight) or non-shippable (digital products)
- **Inventory Management**: Track quantity and handle stock validation
- **Expiration Handling**: Perishable products have expiration dates

### Shopping Cart
- Add products with specific quantities
- Validate against available stock
- Check for expired products
- Calculate subtotals

### Checkout System
- **Validation**: Empty cart, insufficient balance, out of stock, expired products
- **Calculations**: Subtotal, shipping fees, total amount
- **Balance Management**: Update customer balance after payment
- **Receipt Generation**: Detailed checkout information

### Shipping Service
- **Interface Implementation**: Products implement `Shippable` interface
- **Weight Calculation**: Total package weight for shipping
- **Shipment Notice**: Detailed shipping information

## Project Structure
```
src/
├── main/
│   └── java/
│       └── com/
│           └── fawry/
│               ├── model/
│               │   ├── Product.java
│               │   ├── PerishableProduct.java
│               │   ├── NonPerishableProduct.java
│               │   ├── Customer.java
│               │   ├── Cart.java
│               │   ├── CartItem.java
│               │   └── Order.java
│               ├── service/
│               │   ├── ShippingService.java
│               │   └── CheckoutService.java
│               ├── interfaces/
│               │   └── Shippable.java
│               └── Main.java
```

## How to Run

### Prerequisites
- Java 8 or higher
- Maven (optional, for dependency management)

### Compilation and Execution
```bash
# Compile all Java files
javac -d bin src/main/java/com/fawry/**/*.java

# Run the main application
java -cp bin com.fawry.Main
```

## Test Cases Covered

### 1. Basic Product Operations
- Creating perishable and non-perishable products
- Setting expiration dates
- Managing inventory quantities

### 2. Shopping Cart Operations
- Adding products to cart
- Quantity validation
- Stock checking
- Expiration checking

### 3. Checkout Scenarios
- **Successful Checkout**: All validations pass
- **Empty Cart**: Error when trying to checkout empty cart
- **Insufficient Balance**: Error when customer can't afford items
- **Out of Stock**: Error when product quantity is insufficient
- **Expired Products**: Error when trying to buy expired items

### 4. Shipping Integration
- **Shippable Items**: Products with weight sent to shipping service
- **Non-Shippable Items**: Digital products not included in shipping
- **Weight Calculation**: Total package weight calculation

## Example Output
```
** Shipment notice **
2x Cheese 400g
1x Biscuits 700g
Total package weight 1.1kg

** Checkout receipt **
2x Cheese 200
1x Biscuits 150
----------------------
Subtotal 350
Shipping 30
Amount 380
Balance after payment: 620
```

## Assumptions Made

1. **Shipping Fees**: Fixed rate of 30 currency units for any shipment
2. **Weight Units**: Grams for individual items, kilograms for total package
3. **Currency**: Generic currency units (can be easily changed to specific currency)
4. **Date Handling**: Using Java's LocalDate for expiration dates
5. **Error Handling**: Comprehensive validation with descriptive error messages
6. **Product Categories**: Clear distinction between perishable/non-perishable and shippable/non-shippable

## Design Patterns Used

1. **Interface Segregation**: `Shippable` interface for shipping-related products
2. **Inheritance**: Product hierarchy with base `Product` class
3. **Composition**: Cart contains CartItems, Order contains Cart
4. **Service Layer**: Separate services for checkout and shipping logic
5. **Validation Pattern**: Comprehensive input validation throughout the system

## Edge Cases Handled

1. **Negative Quantities**: Prevented at product and cart level
2. **Zero Quantities**: Handled gracefully
3. **Expired Products**: Checked during cart addition and checkout
4. **Insufficient Stock**: Validated before checkout
5. **Empty Cart**: Prevented checkout with empty cart
6. **Insufficient Balance**: Validated before payment processing
7. **Null Values**: Proper null checking throughout the system
8. **Date Validation**: Future expiration dates only

This implementation provides a robust, scalable e-commerce system that meets all the specified requirements while maintaining clean code structure and comprehensive error handling. 