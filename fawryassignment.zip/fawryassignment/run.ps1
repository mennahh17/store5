Write-Host "Compiling Java files..." -ForegroundColor Green

# Create bin directory if it doesn't exist
if (!(Test-Path "bin")) {
    New-Item -ItemType Directory -Path "bin" | Out-Null
}

# Compile all Java files
try {
    javac -d bin src\main\java\com\fawry\interfaces\*.java
    javac -d bin src\main\java\com\fawry\model\*.java
    javac -d bin src\main\java\com\fawry\service\*.java
    javac -d bin src\main\java\com\fawry\Main.java
    
    Write-Host "Compilation successful!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Running the application..." -ForegroundColor Yellow
    Write-Host ""
    
    # Run the application
    java -cp bin com.fawry.Main
    
} catch {
    Write-Host "Compilation failed!" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
}

Write-Host ""
Write-Host "Press any key to continue..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") 