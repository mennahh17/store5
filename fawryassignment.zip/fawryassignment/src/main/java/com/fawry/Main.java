package com.fawry;

import com.fawry.model.*;
import com.fawry.service.CheckoutService;
import java.time.LocalDate;

/**
 * Main class demonstrating the e-commerce system functionality
 * Includes comprehensive test cases covering all requirements
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("=== E-Commerce System - Fawry Quantum Internship Challenge ===\n");
        
        // Create test products
        createAndTestProducts();
        
        // Test successful checkout scenario
        testSuccessfulCheckout();
        
        // Test edge cases
        testEdgeCases();
        
        System.out.println("=== All tests completed successfully! ===");
    }
    
    /**
     * Create and test different types of products
     */
    private static void createAndTestProducts() {
        System.out.println("--- Testing Product Creation ---");
        
        // Create perishable products (Cheese, Biscuits)
        PerishableProduct cheese = new PerishableProduct("Cheese", 100, 10, true, 200, LocalDate.now().plusDays(30));
        PerishableProduct biscuits = new PerishableProduct("Biscuits", 150, 5, true, 700, LocalDate.now().plusDays(15));
        
        // Create non-perishable products (TV, Mobile)
        NonPerishableProduct tv = new NonPerishableProduct("TV", 1000, 3, true, 5000);
        NonPerishableProduct mobile = new NonPerishableProduct("Mobile", 500, 8, false, 0);
        
        // Create digital product (scratch card)
        NonPerishableProduct scratchCard = new NonPerishableProduct("Scratch Card", 50, 20, false, 0);
        
        System.out.println("Products created successfully:");
        System.out.println("- " + cheese);
        System.out.println("- " + biscuits);
        System.out.println("- " + tv);
        System.out.println("- " + mobile);
        System.out.println("- " + scratchCard);
        System.out.println();
    }
    
    /**
     * Test successful checkout scenario as specified in requirements
     */
    private static void testSuccessfulCheckout() {
        System.out.println("--- Testing Successful Checkout ---");
        
        // Create customer with sufficient balance
        Customer customer = new Customer("John Doe", 1000);
        
        // Create products
        PerishableProduct cheese = new PerishableProduct("Cheese", 100, 10, true, 200, LocalDate.now().plusDays(30));
        PerishableProduct biscuits = new PerishableProduct("Biscuits", 150, 5, true, 700, LocalDate.now().plusDays(15));
        NonPerishableProduct scratchCard = new NonPerishableProduct("Scratch Card", 50, 20, false, 0);
        
        // Create cart and add items
        Cart cart = new Cart();
        cart.add(cheese, 2);
        cart.add(biscuits, 1);
        cart.add(scratchCard, 1);
        
        // Process checkout
        CheckoutService checkoutService = new CheckoutService();
        Order order = checkoutService.checkout(customer, cart);
        
        if (order != null) {
            System.out.println("✓ Checkout completed successfully!");
            System.out.println("Order ID: " + order.getOrderId());
        }
        System.out.println();
    }
    
    /**
     * Test various edge cases and error scenarios
     */
    private static void testEdgeCases() {
        System.out.println("--- Testing Edge Cases ---");
        
        // Test 1: Empty cart
        testEmptyCart();
        
        // Test 2: Insufficient balance
        testInsufficientBalance();
        
        // Test 3: Out of stock
        testOutOfStock();
        
        // Test 4: Expired product
        testExpiredProduct();
        
        // Test 5: Negative quantity
        testNegativeQuantity();
        
        // Test 6: Zero quantity
        testZeroQuantity();
        
        // Test 7: Null product
        testNullProduct();
        
        System.out.println("✓ All edge cases handled correctly!");
        System.out.println();
    }
    
    /**
     * Test checkout with empty cart
     */
    private static void testEmptyCart() {
        System.out.println("Testing empty cart checkout...");
        Customer customer = new Customer("Test User", 1000);
        Cart cart = new Cart();
        CheckoutService checkoutService = new CheckoutService();
        
        Order order = checkoutService.checkout(customer, cart);
        if (order == null) {
            System.out.println("✓ Empty cart error handled correctly");
        }
    }
    
    /**
     * Test checkout with insufficient balance
     */
    private static void testInsufficientBalance() {
        System.out.println("Testing insufficient balance...");
        Customer customer = new Customer("Poor User", 50);
        Cart cart = new Cart();
        
        NonPerishableProduct expensiveItem = new NonPerishableProduct("Expensive Item", 1000, 1, true, 1000);
        cart.add(expensiveItem, 1);
        
        CheckoutService checkoutService = new CheckoutService();
        Order order = checkoutService.checkout(customer, cart);
        if (order == null) {
            System.out.println("✓ Insufficient balance error handled correctly");
        }
    }
    
    /**
     * Test checkout with out of stock product
     */
    private static void testOutOfStock() {
        System.out.println("Testing out of stock product...");
        Customer customer = new Customer("Test User", 1000);
        Cart cart = new Cart();
        
        NonPerishableProduct limitedItem = new NonPerishableProduct("Limited Item", 100, 1, true, 500);
        cart.add(limitedItem, 2); // Try to buy more than available
        
        CheckoutService checkoutService = new CheckoutService();
        Order order = checkoutService.checkout(customer, cart);
        if (order == null) {
            System.out.println("✓ Out of stock error handled correctly");
        }
    }
    
    /**
     * Test checkout with expired product
     */
    private static void testExpiredProduct() {
        System.out.println("Testing expired product...");
        Customer customer = new Customer("Test User", 1000);
        Cart cart = new Cart();
        
        // Create expired product (expiration date in the past)
        PerishableProduct expiredItem = new PerishableProduct("Expired Item", 100, 5, true, 200, LocalDate.now().minusDays(1));
        cart.add(expiredItem, 1);
        
        CheckoutService checkoutService = new CheckoutService();
        Order order = checkoutService.checkout(customer, cart);
        if (order == null) {
            System.out.println("✓ Expired product error handled correctly");
        }
    }
    
    /**
     * Test adding product with negative quantity
     */
    private static void testNegativeQuantity() {
        System.out.println("Testing negative quantity...");
        Cart cart = new Cart();
        NonPerishableProduct testItem = new NonPerishableProduct("Test Item", 100, 10, true, 500);
        
        try {
            cart.add(testItem, -1);
            System.out.println("✗ Negative quantity should have been rejected");
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Negative quantity error handled correctly");
        }
    }
    
    /**
     * Test adding product with zero quantity
     */
    private static void testZeroQuantity() {
        System.out.println("Testing zero quantity...");
        Cart cart = new Cart();
        NonPerishableProduct testItem = new NonPerishableProduct("Test Item", 100, 10, true, 500);
        
        try {
            cart.add(testItem, 0);
            System.out.println("✗ Zero quantity should have been rejected");
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Zero quantity error handled correctly");
        }
    }
    
    /**
     * Test adding null product
     */
    private static void testNullProduct() {
        System.out.println("Testing null product...");
        Cart cart = new Cart();
        
        try {
            cart.add(null, 1);
            System.out.println("✗ Null product should have been rejected");
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Null product error handled correctly");
        }
    }
} 