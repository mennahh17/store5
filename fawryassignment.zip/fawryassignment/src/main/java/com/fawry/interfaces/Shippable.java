package com.fawry.interfaces;

public interface Shippable {
    @return 
     
    String getName();
    @return 
    
    double getWeight();
} 