package com.fawry.model;

import java.util.ArrayList;
import java.util.List;


public class Cart {
    private List<CartItem> items;
    
      @param product Product to add
      @param quantity Quantity of the product
     
    public void add(Product product, int quantity) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        if (!product.isAvailable()) {
            throw new IllegalArgumentException("Product is not available (out of stock or expired)");
        }
        if (!product.hasSufficientStock(quantity)) {
            throw new IllegalArgumentException("Insufficient stock for requested quantity");
        }
        
        
        for (CartItem item : items) {
            if (item.getProduct().getName().equals(product.getName())) {
                throw new IllegalArgumentException("Product already exists in cart. Remove existing item first.");
            }
        }
        
        CartItem cartItem = new CartItem(product, quantity);
        items.add(cartItem);
    }
    
     @param productName 
    public void remove(String productName) {
        items.removeIf(item -> item.getProduct().getName().equals(productName));
    }
    
    
     @return 
    public List<CartItem> getItems() {
        return new ArrayList<>(items);
    }
    
     @return 
    public boolean isEmpty() {
        return items.isEmpty();
    }
    
     @return 
    public int getItemCount() {
        return items.size();
    }
    
   @return
    public double getSubtotal() {
        return items.stream()
                   .mapToDouble(CartItem::getTotalPrice)
                   .sum();
    }
    
     @return 
    public List<CartItem> getShippableItems() {
        List<CartItem> shippableItems = new ArrayList<>();
        for (CartItem item : items) {
            if (item.requiresShipping()) {
                shippableItems.add(item);
            }
        }
        return shippableItems;
    }
    
     @return 
     
    public double getTotalShippingWeight() {
        return getShippableItems().stream()
                                 .mapToDouble(CartItem::getTotalWeight)
                                 .sum();
    }
    
    
    public void clear() {
        items.clear();
    }
    
    
    public void updateProductQuantities() {
        for (CartItem item : items) {
            item.getProduct().reduceQuantity(item.getQuantity());
        }
    }
    
    @Override
    public String toString() {
        if (items.isEmpty()) {
            return "Cart is empty";
        }
        
        StringBuilder sb = new StringBuilder();
        for (CartItem item : items) {
            sb.append(item.toString()).append("\n");
        }
        sb.append("Subtotal: ").append(getSubtotal());
        return sb.toString();
    }
} 