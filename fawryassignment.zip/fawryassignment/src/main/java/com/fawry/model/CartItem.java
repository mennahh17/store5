package com.fawry.model;


public class CartItem {
    private Product product;
    private int quantity;
    
    /**
     * Constructor for CartItem
     * @param product Product to add to cart
     * @param quantity Quantity of the product
     */
    public CartItem(Product product, int quantity) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        if (!product.hasSufficientStock(quantity)) {
            throw new IllegalArgumentException("Insufficient stock for requested quantity");
        }
        if (!product.isAvailable()) {
            throw new IllegalArgumentException("Product is not available (out of stock or expired)");
        }
        
        this.product = product;
        this.quantity = quantity;
    }
    
    /**
     * Get the product in this cart item
     * @return Product the product
     */
    public Product getProduct() {
        return product;
    }
    
    /**
     * Get the quantity of this cart item
     * @return int quantity
     */
    public int getQuantity() {
        return quantity;
    }
    
    /**
     * Calculate the total price for this cart item
     * @return double total price (product price * quantity)
     */
    public double getTotalPrice() {
        return product.getPrice() * quantity;
    }
    
    /**
     * Check if this cart item requires shipping
     * @return true if the product requires shipping
     */
    public boolean requiresShipping() {
        return product.requiresShipping();
    }
    
    /**
     * Get the total weight for this cart item
     * @return double total weight in grams
     */
    public double getTotalWeight() {
        return product.getWeight() * quantity;
    }
    
    @Override
    public String toString() {
        return quantity + "x " + product.getName() + " " + (int)getTotalPrice();
    }
} 