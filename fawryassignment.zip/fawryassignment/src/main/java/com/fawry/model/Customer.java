package com.fawry.model;

/**
 * Represents a customer in the e-commerce system
 * Manages customer information and balance
 */
public class Customer {
    private String name;
    private double balance;
    
    /**
     * Constructor for Customer
     * @param name Customer name
     * @param balance Initial balance
     */
    public Customer(String name, double balance) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Customer name cannot be null or empty");
        }
        if (balance < 0) {
            throw new IllegalArgumentException("Customer balance cannot be negative");
        }
        
        this.name = name;
        this.balance = balance;
    }
    
    /**
     * Get customer name
     * @return String customer name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Get current balance
     * @return double current balance
     */
    public double getBalance() {
        return balance;
    }
    
    /**
     * Check if customer has sufficient balance for a purchase
     * @param amount Amount to check
     * @return true if customer has sufficient balance
     */
    public boolean hasSufficientBalance(double amount) {
        return balance >= amount;
    }
    
    /**
     * Deduct amount from customer balance
     * @param amount Amount to deduct
     */
    public void deductBalance(double amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Amount to deduct cannot be negative");
        }
        if (amount > balance) {
            throw new IllegalArgumentException("Insufficient balance for deduction");
        }
        this.balance -= amount;
    }
    
    /**
     * Add amount to customer balance
     * @param amount Amount to add
     */
    public void addBalance(double amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Amount to add cannot be negative");
        }
        this.balance += amount;
    }
    
    @Override
    public String toString() {
        return "Customer: " + name + ", Balance: " + balance;
    }
} 