package com.fawry.model;

/**
 * Represents non-perishable products that do not have an expiration date
 * Examples: TV, Mobile
 */
public class NonPerishableProduct extends Product {
    
    /**
     * Constructor for NonPerishableProduct
     * @param name Product name
     * @param price Product price
     * @param quantity Available quantity
     * @param requiresShipping Whether the product requires shipping
     * @param weight Weight in grams (only used if requiresShipping is true)
     */
    public NonPerishableProduct(String name, double price, int quantity, 
                              boolean requiresShipping, double weight) {
        super(name, price, quantity, requiresShipping, weight);
    }
    
    /**
     * Check if the product is available (in stock)
     * Non-perishable products are available if they have stock
     * @return true if product is available for purchase
     */
    @Override
    public boolean isAvailable() {
        return quantity > 0;
    }
    
    @Override
    public String toString() {
        return super.toString() + " (Non-perishable)";
    }
} 
 