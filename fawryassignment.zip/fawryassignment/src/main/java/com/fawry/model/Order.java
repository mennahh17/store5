package com.fawry.model;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Represents a completed order with all checkout details
 */
public class Order {
    private String orderId;
    private Customer customer;
    private Cart cart;
    private double subtotal;
    private double shippingFees;
    private double totalAmount;
    private LocalDateTime orderDate;
    
    /**
     * Constructor for Order
     * @param orderId Unique order identifier
     * @param customer Customer who placed the order
     * @param cart Cart containing the ordered items
     * @param subtotal Subtotal of all items
     * @param shippingFees Shipping fees
     * @param totalAmount Total amount including shipping
     */
    public Order(String orderId, Customer customer, Cart cart, 
                double subtotal, double shippingFees, double totalAmount) {
        this.orderId = orderId;
        this.customer = customer;
        this.cart = cart;
        this.subtotal = subtotal;
        this.shippingFees = shippingFees;
        this.totalAmount = totalAmount;
        this.orderDate = LocalDateTime.now();
    }
    
    // Getters
    public String getOrderId() {
        return orderId;
    }
    
    public Customer getCustomer() {
        return customer;
    }
    
    public Cart getCart() {
        return cart;
    }
    
    public double getSubtotal() {
        return subtotal;
    }
    
    public double getShippingFees() {
        return shippingFees;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public LocalDateTime getOrderDate() {
        return orderDate;
    }
    
    /**
     * Get all items in the order
     * @return List of CartItem objects
     */
    public List<CartItem> getItems() {
        return cart.getItems();
    }
    
    /**
     * Get shippable items from the order
     * @return List of CartItem objects that require shipping
     */
    public List<CartItem> getShippableItems() {
        return cart.getShippableItems();
    }
    
    /**
     * Get total shipping weight
     * @return double total weight in grams
     */
    public double getTotalShippingWeight() {
        return cart.getTotalShippingWeight();
    }
    
    @Override
    public String toString() {
        return "Order ID: " + orderId + 
               ", Customer: " + customer.getName() + 
               ", Total: " + totalAmount + 
               ", Date: " + orderDate;
    }
} 