package com.fawry.model;

import com.fawry.interfaces.Shippable;
import java.time.LocalDate;

/**
 * Represents perishable products that have an expiration date
 * Examples: Cheese, Biscuits
 */
public class PerishableProduct extends Product implements Shippable {
    private LocalDate expirationDate;
    
    /**
     * Constructor for PerishableProduct
     * @param name Product name
     * @param price Product price
     * @param quantity Available quantity
     * @param requiresShipping Whether the product requires shipping
     * @param weight Weight in grams (only used if requiresShipping is true)
     * @param expirationDate Expiration date of the product
     */
    public PerishableProduct(String name, double price, int quantity, 
                           boolean requiresShipping, double weight, LocalDate expirationDate) {
        super(name, price, quantity, requiresShipping, weight);
        
        if (expirationDate == null) {
            throw new IllegalArgumentException("Expiration date cannot be null");
        }
        if (expirationDate.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Expiration date cannot be in the past");
        }
        
        this.expirationDate = expirationDate;
    }
    
    /**
     * Get the expiration date of the product
     * @return LocalDate expiration date
     */
    public LocalDate getExpirationDate() {
        return expirationDate;
    }
    
    /**
     * Check if the product is expired
     * @return true if the product has expired
     */
    public boolean isExpired() {
        return LocalDate.now().isAfter(expirationDate);
    }
    
    /**
     * Check if the product is available (in stock and not expired)
     * @return true if product is available for purchase
     */
    @Override
    public boolean isAvailable() {
        return quantity > 0 && !isExpired();
    }
    
    @Override
    public String toString() {
        return super.toString() + ", Expires: " + expirationDate;
    }
} 