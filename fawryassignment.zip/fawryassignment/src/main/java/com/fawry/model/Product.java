package com.fawry.model;

import java.time.LocalDate;

/**
 * Base class for all products in the e-commerce system
 * Contains common properties and methods for all products
 */
public abstract class Product {
    protected String name;
    protected double price;
    protected int quantity;
    protected boolean requiresShipping;
    protected double weight; // in grams, only relevant if requiresShipping is true
    
    /**
     * Constructor for Product
     * @param name Product name
     * @param price Product price
     * @param quantity Available quantity
     * @param requiresShipping Whether the product requires shipping
     * @param weight Weight in grams (only used if requiresShipping is true)
     */
    public Product(String name, double price, int quantity, boolean requiresShipping, double weight) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Product name cannot be null or empty");
        }
        if (price < 0) {
            throw new IllegalArgumentException("Product price cannot be negative");
        }
        if (quantity < 0) {
            throw new IllegalArgumentException("Product quantity cannot be negative");
        }
        if (requiresShipping && weight <= 0) {
            throw new IllegalArgumentException("Shippable products must have positive weight");
        }
        
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.requiresShipping = requiresShipping;
        this.weight = weight;
    }
    
    // Getters
    public String getName() {
        return name;
    }
    
    public double getPrice() {
        return price;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public boolean requiresShipping() {
        return requiresShipping;
    }
    
    public double getWeight() {
        return weight;
    }
    
    /**
     * Check if the product is available (in stock and not expired)
     * @return true if product is available for purchase
     */
    public abstract boolean isAvailable();
    
    /**
     * Reduce the quantity of the product
     * @param amount Amount to reduce
     */
    public void reduceQuantity(int amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Amount to reduce cannot be negative");
        }
        if (amount > quantity) {
            throw new IllegalArgumentException("Cannot reduce quantity by more than available stock");
        }
        this.quantity -= amount;
    }
    
    /**
     * Check if the product has sufficient stock for the requested quantity
     * @param requestedQuantity Quantity requested
     * @return true if sufficient stock is available
     */
    public boolean hasSufficientStock(int requestedQuantity) {
        return requestedQuantity > 0 && requestedQuantity <= quantity;
    }
    
    @Override
    public String toString() {
        return name + " - Price: " + price + ", Quantity: " + quantity;
    }
} 