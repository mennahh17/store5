package com.fawry.service;

import com.fawry.model.*;
import java.util.List;

/**
 * Service for handling checkout operations
 * Manages the complete checkout process including validations and calculations
 */
public class CheckoutService {
    private static final double SHIPPING_FEE = 30.0; // Fixed shipping fee
    private ShippingService shippingService;
    
    /**
     * Constructor for CheckoutService
     */
    public CheckoutService() {
        this.shippingService = new ShippingService();
    }
    
    /**
     * Process checkout for a customer with their cart
     * @param customer Customer making the purchase
     * @param cart Cart containing items to purchase
     * @return Order object if checkout is successful, null otherwise
     */
    public Order checkout(Customer customer, Cart cart) {
        try {
            // Validate checkout
            validateCheckout(customer, cart);
            
            // Calculate totals
            double subtotal = cart.getSubtotal();
            double shippingFees = calculateShippingFees(cart);
            double totalAmount = subtotal + shippingFees;
            
            // Process payment
            customer.deductBalance(totalAmount);
            
            // Update product quantities
            cart.updateProductQuantities();
            
            // Process shipping
            List<CartItem> shippableItems = cart.getShippableItems();
            if (!shippableItems.isEmpty()) {
                shippingService.processCartShipping(shippableItems);
            }
            
            // Create and return order
            String orderId = generateOrderId();
            Order order = new Order(orderId, customer, cart, subtotal, shippingFees, totalAmount);
            
            // Print receipt
            printReceipt(order);
            
            return order;
            
        } catch (Exception e) {
            System.out.println("Checkout failed: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Validate the checkout process
     * @param customer Customer making the purchase
     * @param cart Cart containing items to purchase
     */
    private void validateCheckout(Customer customer, Cart cart) {
        // Check if cart is empty
        if (cart.isEmpty()) {
            throw new IllegalStateException("Cart is empty");
        }
        
        // Check if all products are available
        for (CartItem item : cart.getItems()) {
            Product product = item.getProduct();
            if (!product.isAvailable()) {
                throw new IllegalStateException("Product " + product.getName() + " is not available (out of stock or expired)");
            }
            if (!product.hasSufficientStock(item.getQuantity())) {
                throw new IllegalStateException("Insufficient stock for " + product.getName());
            }
        }
        
        // Calculate total amount
        double subtotal = cart.getSubtotal();
        double shippingFees = calculateShippingFees(cart);
        double totalAmount = subtotal + shippingFees;
        
        // Check if customer has sufficient balance
        if (!customer.hasSufficientBalance(totalAmount)) {
            throw new IllegalStateException("Insufficient balance. Required: " + totalAmount + ", Available: " + customer.getBalance());
        }
    }
    
    /**
     * Calculate shipping fees based on cart contents
     * @param cart Cart to calculate shipping for
     * @return double shipping fees
     */
    private double calculateShippingFees(Cart cart) {
        List<CartItem> shippableItems = cart.getShippableItems();
        return shippableItems.isEmpty() ? 0.0 : SHIPPING_FEE;
    }
    
    /**
     * Generate a unique order ID
     * @return String order ID
     */
    private String generateOrderId() {
        return "ORD-" + System.currentTimeMillis();
    }
    
    /**
     * Print the checkout receipt
     * @param order Order to print receipt for
     */
    private void printReceipt(Order order) {
        System.out.println("** Checkout receipt **");
        
        // Print items
        for (CartItem item : order.getItems()) {
            System.out.printf("%dx %s %d%n", 
                item.getQuantity(), 
                item.getProduct().getName(), 
                (int)item.getTotalPrice());
        }
        
        // Print totals
        System.out.println("----------------------");
        System.out.printf("Subtotal %d%n", (int)order.getSubtotal());
        System.out.printf("Shipping %d%n", (int)order.getShippingFees());
        System.out.printf("Amount %d%n", (int)order.getTotalAmount());
        System.out.printf("Balance after payment: %d%n", (int)order.getCustomer().getBalance());
        System.out.println();
    }
} 