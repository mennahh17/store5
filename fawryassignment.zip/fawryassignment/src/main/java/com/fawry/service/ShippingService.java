package com.fawry.service;

import com.fawry.interfaces.Shippable;
import java.util.List;

/**
 * Service for handling shipping operations
 * Accepts shippable items and processes shipping information
 */
public class ShippingService {
    
    /**
     * Process shipping for a list of shippable items
     * @param shippableItems List of items that need to be shipped
     */
    public void processShipping(List<Shippable> shippableItems) {
        if (shippableItems == null || shippableItems.isEmpty()) {
            System.out.println("No items to ship.");
            return;
        }
        
        System.out.println("** Shipment notice **");
        
        double totalWeight = 0;
        for (Shippable item : shippableItems) {
            String name = item.getName();
            double weight = item.getWeight();
            totalWeight += weight;
            
            // Convert grams to kilograms for display
            double weightInKg = weight / 1000.0;
            System.out.printf("%s %.1fkg%n", name, weightInKg);
        }
        
        // Display total package weight
        double totalWeightInKg = totalWeight / 1000.0;
        System.out.printf("Total package weight %.1fkg%n", totalWeightInKg);
        System.out.println();
    }
    
    /**
     * Process shipping for cart items that require shipping
     * @param cartItems List of cart items to process for shipping
     */
    public void processCartShipping(List<com.fawry.model.CartItem> cartItems) {
        if (cartItems == null || cartItems.isEmpty()) {
            System.out.println("No items to ship.");
            return;
        }
        
        System.out.println("** Shipment notice **");
        
        double totalWeight = 0;
        for (com.fawry.model.CartItem item : cartItems) {
            if (item.requiresShipping()) {
                String name = item.getProduct().getName();
                double weight = item.getTotalWeight();
                totalWeight += weight;
                
                // Display in grams for individual items
                System.out.printf("%dx %s %.0fg%n", item.getQuantity(), name, weight);
            }
        }
        
        // Display total package weight in kg
        double totalWeightInKg = totalWeight / 1000.0;
        System.out.printf("Total package weight %.1fkg%n", totalWeightInKg);
        System.out.println();
    }
} 